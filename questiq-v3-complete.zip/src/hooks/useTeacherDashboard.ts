// src/hooks/useTeacherDashboard.ts
// ─────────────────────────────────────────────────────────────────────────────
// 교사 대시보드 상태 관리 훅
// - 학생 목록 CRUD (로컬스토리지 영속)
// - 클래스 통계 memoized 계산
// - 데모 데이터 시드
// ─────────────────────────────────────────────────────────────────────────────
import { useState, useCallback, useMemo, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { StudentRecord, ClassStats, AiComment } from '../types/teacher';
import type { DiagnosticResult, DiagnosticComparison, ConstructId } from '../types/diagnostic';
import { CONSTRUCTS } from '../data/diagnosticData';

const STORAGE_KEY = 'questiq_teacher_students';

// ── 데모 학생 데이터 생성기 ───────────────────────────
function makeDemoStudent(
  name: string, grade: string, group: string,
  preAvgs: number[], postAvgs: number[]
): StudentRecord {
  const makeResult = (type: 'pre' | 'post', avgs: number[]): DiagnosticResult => {
    const constructScores = CONSTRUCTS.map((c, i) => ({
      constructId: c.id as ConstructId,
      rawScores: Array(4).fill(Math.round(avgs[i])),
      averageScore: avgs[i],
      normalizedScore: Math.round(((avgs[i] - 1) / 4) * 100),
      level: (avgs[i] >= 4.2 ? 'very_high' : avgs[i] >= 3.4 ? 'high' : avgs[i] >= 2.6 ? 'medium' : 'low') as any,
    }));
    const totalAverage = avgs.reduce((a, b) => a + b, 0) / avgs.length;
    return {
      id: uuidv4(), type,
      constructScores,
      totalAverage: Math.round(totalAverage * 100) / 100,
      totalNormalized: Math.round(((totalAverage - 1) / 4) * 100),
      totalLevel: (totalAverage >= 4.2 ? 'very_high' : totalAverage >= 3.4 ? 'high' : totalAverage >= 2.6 ? 'medium' : 'low') as any,
      completedAt: new Date(Date.now() - (type === 'pre' ? 14 : 0) * 86400000).toISOString(),
    };
  };

  const pre  = makeResult('pre',  preAvgs);
  const post = makeResult('post', postAvgs);
  const constructComparisons = CONSTRUCTS.map((c, i) => ({
    constructId: c.id as ConstructId,
    preScore: preAvgs[i], postScore: postAvgs[i],
    improvement: Math.round((postAvgs[i] - preAvgs[i]) * 100) / 100,
    improvementPct: Math.round(((postAvgs[i] - preAvgs[i]) / preAvgs[i]) * 100),
    isSignificant: Math.abs(postAvgs[i] - preAvgs[i]) >= 0.5,
  }));
  const totalImprovement = Math.round((post.totalAverage - pre.totalAverage) * 100) / 100;
  const comparison: DiagnosticComparison = {
    pre, post, constructComparisons,
    totalImprovement,
    totalImprovementPct: Math.round((totalImprovement / pre.totalAverage) * 100),
    mostImprovedConstruct: constructComparisons.reduce((a, b) => a.improvement > b.improvement ? a : b).constructId,
    leastImprovedConstruct: constructComparisons.reduce((a, b) => a.improvement < b.improvement ? a : b).constructId,
    overallGrowthLevel: totalImprovement >= 1.5 ? 'remarkable' : totalImprovement >= 0.8 ? 'significant' : totalImprovement >= 0.3 ? 'moderate' : totalImprovement >= 0 ? 'slight' : 'declined',
    summary: `${name} 학생의 질문 역량이 전체적으로 향상되었습니다.`,
  };

  return { id: uuidv4(), name, grade, group, pre, post, comparison, addedAt: new Date().toISOString() };
}

const DEMO_STUDENTS: StudentRecord[] = [
  makeDemoStudent('김민준', '중학교 2학년', '1모둠', [2.5,2.8,2.3,2.6,2.4,2.7], [3.8,4.1,3.5,3.7,3.9,3.6]),
  makeDemoStudent('이서연', '중학교 2학년', '1모둠', [3.2,3.0,3.5,3.1,2.9,3.3], [4.2,4.0,4.3,4.1,3.8,4.2]),
  makeDemoStudent('박지호', '중학교 2학년', '2모둠', [2.1,2.4,2.0,2.3,2.2,2.5], [3.0,3.3,2.8,3.2,3.1,3.4]),
  makeDemoStudent('최하은', '중학교 2학년', '2모둠', [3.8,3.6,3.9,3.7,3.5,3.8], [4.5,4.3,4.6,4.4,4.2,4.5]),
  makeDemoStudent('정도현', '중학교 2학년', '3모둠', [2.8,3.1,2.6,2.9,2.7,3.0], [3.4,3.7,3.2,3.6,3.3,3.8]),
  makeDemoStudent('윤수아', '중학교 2학년', '3모둠', [3.5,3.3,3.7,3.2,3.4,3.6], [3.8,3.6,4.0,3.5,3.7,3.9]),
  makeDemoStudent('강태민', '중학교 2학년', '4모둠', [2.3,2.6,2.2,2.5,2.1,2.4], [2.6,2.9,2.5,2.8,2.4,2.7]),
  makeDemoStudent('오유진', '중학교 2학년', '4모둠', [4.0,3.8,4.1,3.9,3.7,4.0], [4.6,4.4,4.7,4.5,4.3,4.6]),
];

// ── 훅 ────────────────────────────────────────────────
export function useTeacherDashboard() {
  const [students, setStudents] = useState<StudentRecord[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch { /* ignore */ }
    return DEMO_STUDENTS;
  });

  // 영속화
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(students)); }
    catch { /* ignore */ }
  }, [students]);

  // AI 코멘트 업데이트
  const setAiComment = useCallback((studentId: string, comment: AiComment) => {
    setStudents(prev => prev.map(s =>
      s.id === studentId ? { ...s, aiComment: comment } : s
    ));
  }, []);

  // 학생 추가 (테스트용)
  const addStudent = useCallback((record: Omit<StudentRecord, 'id' | 'addedAt'>) => {
    const newRecord: StudentRecord = { ...record, id: uuidv4(), addedAt: new Date().toISOString() };
    setStudents(prev => [...prev, newRecord]);
  }, []);

  // 학생 삭제
  const removeStudent = useCallback((id: string) => {
    setStudents(prev => prev.filter(s => s.id !== id));
  }, []);

  // 데모 데이터 리셋
  const resetToDemo = useCallback(() => setStudents(DEMO_STUDENTS), []);

  // 클래스 통계 계산
  const classStats = useMemo<ClassStats>(() => {
    const withBoth = students.filter(s => s.comparison);
    const withPre  = students.filter(s => s.pre);

    const constructAvgPre  = {} as Record<ConstructId, number>;
    const constructAvgPost = {} as Record<ConstructId, number>;
    CONSTRUCTS.forEach(c => {
      const preScores  = withBoth.map(s => s.pre!.constructScores.find(cs => cs.constructId === c.id)!.averageScore);
      const postScores = withBoth.map(s => s.post!.constructScores.find(cs => cs.constructId === c.id)!.averageScore);
      constructAvgPre[c.id as ConstructId]  = preScores.length  ? preScores.reduce((a,b)=>a+b,0)/preScores.length   : 0;
      constructAvgPost[c.id as ConstructId] = postScores.length ? postScores.reduce((a,b)=>a+b,0)/postScores.length : 0;
    });

    const improvements = CONSTRUCTS.map(c => ({
      id: c.id as ConstructId,
      diff: (constructAvgPost[c.id as ConstructId] ?? 0) - (constructAvgPre[c.id as ConstructId] ?? 0),
    }));
    const topImprovedConstruct = improvements.reduce((a, b) => a.diff > b.diff ? a : b).id;

    const avgPreTotal  = withBoth.length ? withBoth.reduce((a,s)=>a+s.pre!.totalAverage,0)/withBoth.length   : 0;
    const avgPostTotal = withBoth.length ? withBoth.reduce((a,s)=>a+s.post!.totalAverage,0)/withBoth.length  : 0;

    return {
      totalStudents: students.length,
      completedBoth: withBoth.length,
      completedPre: withPre.length,
      avgPreTotal: Math.round(avgPreTotal * 100) / 100,
      avgPostTotal: Math.round(avgPostTotal * 100) / 100,
      avgImprovement: Math.round((avgPostTotal - avgPreTotal) * 100) / 100,
      constructAvgPre,
      constructAvgPost,
      topImprovedConstruct,
    };
  }, [students]);

  return { students, classStats, setAiComment, addStudent, removeStudent, resetToDemo };
}
